Instructions for use:

1. Click on Automater.bat

2. Enter URL, Hash or filename you wish to scan. 

If you want to use a file with a list of targets, change directory to findings/lib and paste the file there.